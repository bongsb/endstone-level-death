from endstone_level_death.level_death import LevelDeathPenalty

__all__ = ["LevelDeathPenalty"]